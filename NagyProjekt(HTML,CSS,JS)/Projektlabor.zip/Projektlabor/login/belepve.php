<?php
require 'system/start.php';

/* Ez az oldal már védett */
$user = new FELHASZNALO;
$user->vedelem();

$u = $user->user_adatai();
if(isset($_GET['logout'])) $user->logout();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Használtautó</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" type="text/css" href="css/belepve_style.css"/>
    <link rel="stylesheet" type="text/css" href="css/responsive.css"/>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/jwerty.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/belepve_script.js"></script>
    
</head>
<body>
    <div class="loading-overlay"></div>
    <div class="loading">
        <div>Töltés... Kérlek várj!</div>
        <img src="img/loader.gif" alt="Töltés..." />
    </div>
    <script>loading()</script>
<div id="wrapper">
	
<div class="belepve">          

<div class="Kijelentkezik">
<div class="adatok">
Sikeresen beléptél, mint <b><?php echo $u['username'] ?></b>          

            <?php if($u['jogok'] > 1) echo 'A jogkörd nagyobb, mint 1, ezért: <a href="admin">Adminfelület</a>'; ?><br />
</div>
<a href="?logout">Kijelentkezés</a>

</div>      


<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'Szemelyauto')"><i class="fa fa-car"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Motor')"><i class="fa fa-motorcycle"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Teher')"><i class="fa fa-truck"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Egyeb')"><i class="fa fa-ellipsis-h"></i></button>
 <div class="cim">
		<h2>Használtautó</h2>
		
	</div>
	

  
</div>


<div id="Szemelyauto" class="tabcontent">
 <p>Személyautók</p>
  <div class="autoJellemzo">  

		<p>Márka:</p>
			<select id="autokLista">
				<option>Kattints!</option>
				<option>Audi</option>
				<option>BMW</option>
				<option>Ford</option>
				<option>Mercedes</option>
				<option>Opel</option>
				<option>UAZ</option>
			</select>
		
  
  </div>
  
  
</div>

<div id="Motor" class="tabcontent">
  <p>Motorkerékpárok</p> 
  		<p>Márka:</p>
			<select id="motorokLista">
				<option>Kattints!</option>
				<option>Aprilia</option>
				<option>Babetta</option>
				<option>Ducati</option>
				<option>Honda</option>
				<option>Kawasaki</option>
				<option>Yamaha</option>
			</select>
</div>

<div id="Teher" class="tabcontent">
  <p>Teherautók</p>
    		<p>Márka:</p>
			<select id="kishaszonjarmuvekLista">
				<option>Kattints!</option>
				<option>Barkas</option>
				<option>Citroen</option>
				<option>Fiat</option>
				<option>Isuzu</option>
				<option>Mazda</option>
				<option>Renault</option>
			</select>
</div>

<div id="Egyeb" class="tabcontent">
  <p>Egyéb</p>
      		<p>Márka:</p>
			<select id="egyebLista">
				<option>Kattints!</option>
				<option>DAF</option>
				<option>Humer</option>
				<option>JCB</option>
				<option>Luxi</option>
				<option>Polaris</option>
			</select>
</div>




</body>
<script>loading(0)</script>
</html>