<?php
require 'system/start.php';

/* Ez az oldal már védett */
$user = new FELHASZNALO;
$user->vedelem();

$u = $user->user_adatai();
if(isset($_GET['logout'])) $user->logout();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Használtautó</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" type="text/css" href="css/belepve_style.css"/>
    <link rel="stylesheet" type="text/css" href="css/responsive.css"/>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/jwerty.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/belepve_script.js"></script>
    
</head>
<body>
    <div class="loading-overlay"></div>
    <div class="loading">
        <div>Töltés... Kérlek várj!</div>
        <img src="img/loader.gif" alt="Töltés..." />
    </div>
    <script>loading()</script>
<div id="wrapper">
	
<div class="belepve">          

<div class="Kijelentkezik">
<div class="adatok">
Sikeresen beléptél, mint <b><?php echo $u['username'] ?></b>          

            <?php if($u['jogok'] > 1) echo 'A jogkörd nagyobb, mint 1, ezért: <a href="admin">Adminfelület</a>'; ?><br />
</div>
<a href="?logout">Kijelentkezés</a>

</div>      


<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'Szemelyauto')"><i class="fa fa-car"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Motor')"><i class="fa fa-motorcycle"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Teher')"><i class="fa fa-truck"></i></button>
  <button class="tablinks" onclick="openCity(event, 'Egyeb')"><i class="fa fa-ellipsis-h"></i></button>
 <div class="cim">
		<h2>Használtautó</h2>
		
	</div>
	

  
</div>


<div id="Szemelyauto" class="tabcontent">
 <p>Személyautók</p>
  <div class="autoJellemzo">  

		<p>Márka:</p>
			<select id="autokLista">
				<option value="0">Kattints!</option>
				<option value="1">Audi</option>
				<option value="2">BMW</option>
				<option value="3">Ford</option>
				<option value="4">Mercedes</option>
				<option value="5">Opel</option>
				<option value="6">UAZ</option>
			</select>
		<div id="kepek">
		</div>
  
  </div>
  
  
</div>

<div id="Motor" class="tabcontent">
  <p>Motorkerékpárok</p> 
  		<p>Márka:</p>
			<select id="motorokLista">
				<option value="0">Kattints!</option>
				<option value="1">Aprilia</option>
				<option value="2">Babetta</option>
				<option value="3">Ducati</option>
				<option value="4">Honda</option>
				<option value="5">Kawasaki</option>
				<option value="6">Yamaha</option>
			</select>
			<div id="kepek2">
		</div>
			
</div>

<div id="Teher" class="tabcontent">
  <p>Teherautók</p>
    		<p>Márka:</p>
			<select id="kishaszonjarmuvekLista">
				<option value="0">Kattints!</option>
				<option value="1">Barkas</option>
				<option value="2">Citroen</option>
				<option value="3">Fiat</option>
				<option value="4">Isuzu</option>
				<option value="5">Mazda</option>
				<option value="6">Renault</option>
			</select>
			<div id="kepek3">
		</div>
</div>

<div id="Egyeb" class="tabcontent">
  <p>Egyéb</p>
      		<p>Márka:</p>
			<select id="egyebLista">
				<option value="0">Kattints!</option>
				<option value="1">DAF</option>
				<option value="2">RIB</option>
				<option value="3">JCB</option>
				<option value="4">Humer</option>
				<option value="5">Polaris</option>
			</select>
			<div id="kepek4">
		</div>
</div>




</body>
<script>loading(0)
var languageDropdown = document.getElementById("autokLista");

languageDropdown.onchange = function(){
	var e = document.getElementById("autokLista");
	document.getElementById('kepek').innerHTML = "";
	if(e.options[e.selectedIndex].value == 1){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/audi/audi_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek').appendChild(x);
		}
	}
	if(e.options[e.selectedIndex].value == 2){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/bmw/bmw_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek').appendChild(x);
		}
	}
		if(e.options[e.selectedIndex].value == 3){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/ford/FORD_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek').appendChild(x);
		}
	}
};

//MOTOR------------------------------------------------------------------------------------

var languageDropdown = document.getElementById("motorokLista");

languageDropdown.onchange = function(){
	var e = document.getElementById("motorokLista");
	document.getElementById('kepek2').innerHTML = "";
	if(e.options[e.selectedIndex].value == 1){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/aprillia/APRILIA_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek2').appendChild(x);
		}
	}
	if(e.options[e.selectedIndex].value == 2){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/babetta/BABETTA_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek2').appendChild(x);
		}
	}
		if(e.options[e.selectedIndex].value == 3){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/ducati/DUCATI_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek2').appendChild(x);
		}
	}
};

//KISHASZONJÁRMŰ------------------------------------------------------------------------------------


var languageDropdown = document.getElementById("kishaszonjarmuvekLista");

languageDropdown.onchange = function(){
	var e = document.getElementById("kishaszonjarmuvekLista");
	document.getElementById('kepek3').innerHTML = "";
	if(e.options[e.selectedIndex].value == 1){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/barkas/BARKAS_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek3').appendChild(x);
		}
	}
	if(e.options[e.selectedIndex].value == 2){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/citroen/CITROEN_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek3').appendChild(x);
		}
	}
		if(e.options[e.selectedIndex].value == 3){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/fiat/FIAT_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek3').appendChild(x);
		}
	}
};




//EGYÉB------------------------------------------------------------------------------------


var languageDropdown = document.getElementById("egyebLista");

languageDropdown.onchange = function(){
	var e = document.getElementById("egyebLista");
	document.getElementById('kepek4').innerHTML = "";
	if(e.options[e.selectedIndex].value == 1){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/daf/DAF_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px")
				document.getElementById('kepek4').appendChild(x);
		}
	}
	if(e.options[e.selectedIndex].value == 3){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/jcb/JCB_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek4').appendChild(x);
		}
	}
		if(e.options[e.selectedIndex].value == 2){
		for(var i = 1; i < 4; i++){
				var x = document.createElement("IMG");
				x.setAttribute("src", "./img/rib/RIB_" + i + ".png");
				//x.setAttribute("width", 100%);
				x.setAttribute("height", "450px");
				document.getElementById('kepek4').appendChild(x);
		}
	}
};
</script>
</html>