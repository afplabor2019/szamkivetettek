<?php
require 'system/start.php';
$muvelet = $_POST['muvelet'];


switch($muvelet) {
    case 'login':
        $user = new FELHASZNALO;
        $user->login($_POST['user'],$_POST['pw']);
    break;
    case 'lostpw':
        $user = new FELHASZNALO;
        $user->lostpw($_POST['u'],$_POST['email']);
    break;
    case 'reg':
        $user = new FELHASZNALO;
        $reg = $user->reg($_POST['user'],$_POST['pw'],$_POST['rpw'],$_POST['email']);
        if($reg) echo '<div class="csik csik-jo">Sikeresen regisztráltál! Küldtünk egy visszaigazoló e-mailt ide: '. $_POST['email'] .'</div>';
    break;
    case 'save_settings':
        $user = new FELHASZNALO;
        $u = $user->user_adatai();
        if ($u['jogok'] < 2) die('<div class="csik csik-veszely">Hiba történt a mentéskor!</div>');
        
        $db->query("UPDATE settings SET email='{$_POST['email']}',url='{$_POST['url']}',oldal_nev='{$_POST['oldal_nev']}',nyilt_reg='{$_POST['nyitott']}',max_users={$_POST['max_users']},kell_email='{$_POST['megerosites']}'");
        echo '<div class="csik csik-jo">A változtatások elmentve!</div>';
    break;
}
?>