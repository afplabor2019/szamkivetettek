<?php
require 'system/start.php';

/* Ez az oldal már védett */
$user = new FELHASZNALO;
$user->vedelem();

/* Ha nem admin, akkor átirányítjuk */
$u = $user->user_adatai();
if($u['jogok'] <=1 ) atiranyit('fooldal');

/*Összerakjuk az admin oldal tartalmát*/
#E-mail
?>
<!DOCTYPE html>
<html>
<head>
    <title>Adminfelület beléptetőrendszerhez</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />
    
    <script src="js/jquery.min.js"></script>
    <script src="js/jwerty.min.js"></script>
    <script src="js/script.js"></script>
    
</head>
<body>
    <div class="loading-overlay"></div>
    <div class="loading">
        <div>Töltés... Kérlek várj!</div>
        <img src="img/loader.gif" alt="Töltés..." />
    </div>
    <script>loading()</script>
    <div id="wrapper">
        <table id="admin">
            <tr style="text-align: center; font-size: 18px">
                <td colspan="2"><a href="fooldal">[Vissza a főoldalra]</a></td>
            </tr>
            <tr>
                <td colspan="2" class="save_err"></td>
            </tr>
            <tr>
                <td>Oldal e-mail címe</td>
                <td class="inputs"><input type="text" id="email" value="<?php echo $settings['email']; ?>" /></td>
            </tr>
            <tr>
                <td>
                    Oldal url címe<br />
                    <small>A végén '/' (per jel) nélkül</small>
                </td>
                <td class="inputs"><input type="text" id="url" value="<?php echo $settings['url']; ?>" /></td>
            </tr>
            <tr>
                <td>Oldal neve</td>
                <td class="inputs"><input type="text" id="oldal_nev" value="<?php echo $settings['oldal_nev']; ?>" /></td>
            </tr>
            <tr>
                <td>Nyitott-e a regisztráció</td>
                <td class="inputs">
                    <select id="nyitott">
                        <option value="true">Nyitott</option>
                        <option value="false" <?php if($settings['nyilt_reg'] == 'false') echo 'selected="selected"' ?>>Zárt</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Max. felhasználó</td>
                <td class="inputs"><input type="number" id="max_users" value="<?php echo $settings['max_users']; ?>" /></td>
            </tr>
            <tr>
                <td>Meg kell-e erősíteni az e-mailt a belépéshez</td>
                <td class="inputs">
                    <select id="megerosites">
                        <option value="igen">Igen, meg kell</option>
                        <option value="nem" <?php if($settings['kell_email'] == 'nem') echo 'selected="selected"' ?>>Nem, nem kell</option>
                    </select>
</td>
            </tr>
            <tr style="text-align: center; height: 80px">
                <td colspan="2"><input type="button" value="Mentés" onclick="save_settings()" /></td>
            </tr>
        </table>
    </div>
</body>
<script>loading(0)</script>
</html>