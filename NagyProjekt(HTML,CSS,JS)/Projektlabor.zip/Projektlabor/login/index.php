<?php
require 'system/start.php';

$user = new FELHASZNALO;
$user->vedelem('nem');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Beléptetőrendszer by Teoni</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />
    
    <script src="js/jquery.min.js"></script>
    <script src="js/jwerty.min.js"></script>
    <script src="js/script.js"></script>
    
    <script>
        $(function() {
            $("form.login").bind("keydown", jwerty.event("enter", function(){
                login();
            }));
            $("form.reg").bind("keydown", jwerty.event("enter", function(){
                reg();
            }));
            $("form.lostpw").bind("keydown", jwerty.event("enter", function(){
                lostpw();
            }));
        });
    </script>
</head>
<body>
    <div class="loading-overlay"></div>
    <div class="loading">
        <div>Töltés... Kérlek várj!</div>
        <img src="img/loader.gif" alt="Töltés..." />
    </div>
    <script>loading()</script>
    <div id="wrapper">
        <div class="login">
            <h1 class="login">Bejelentkezés</h1>
            <hr />
            <div class="login_err"></div>
            <div class="img-lock"></div>
            <form class="login">
                <input type="text" name="user" id="user" placeholder="Felhasználónév" autofocus="" /><br />
                <input type="password" name="pw" id="pw" placeholder="Jelszó" /><br />
                <input type="button" onclick="login()" value="Belépés" /><br />
                <div style="margin-top: 20px;">Még nem regisztráltál? <a href="#" onclick="reg_form()">Itt megteheted!</a></div>
            </form>
            <form class="reg">
                <input type="text" name="wantuser" id="wantuser" onkeyup="check_pw()" placeholder="Felhasználónév" /><br />
                <input type="password" name="wantpw" id="wantpw" onkeyup="check_pw()" placeholder="Jelszó" /><br />
                <input type="password" name="wantrpw" id="wantrpw" placeholder="Jelszó újra" /><br />
                <input type="email" name="wantemail" id="wantemail" placeholder="E-mail cím" /><br />
                <input type="button" onclick="reg()" value="Regisztráció" /><br />
                <div style="margin-top: 20px;"><a href="#" onclick="login_form()">Vissza</a></div>
            </form>
            <form class="lostpw">
                <input type="text" name="lostu" id="lostu" placeholder="Felhasználónév" /><br />
                <input type="email" name="lostemail" id="lostemail" placeholder="E-mail cím" /><br />
                <input type="button" onclick="lostpw()" value="Jelszóújítás" /><br />
                <div style="margin-top: 20px;"><a href="#" onclick="login_form2()">Vissza</a></div>
            </form>
        </div>
    </div>
</body>
<script>loading(0)</script>
</html>