<?php
require 'system/start.php';
$u = $_GET['u'];
$pw = $_GET['pw'];
$db->query('SELECT status,pw FROM users WHERE username="'. $u .'"');
$status = $db->fetch_arr();
if($status['pw'] != $pw) {
    $eredmeny = '<div class="csik csik-veszely">Váratlan hiba történt. <a href="fooldal">Főoldal</a></div>';
} elseif($status['status'] == 'progress'){
    $db->query('UPDATE users SET status="confirmed" WHERE username="'. $u .'" AND pw="'. $pw .'"');
    $eredmeny = '<div class="csik csik-jo">Az e-mail címedet sikeresen visszaigazoltad! Mostmár bejelentkezhetsz <a href="belepes">itt.</a></div>';
} else {
    $eredmeny = '<div class="csik csik-jo">Az e-mail címedet már megerősítetted. <a href="fooldal">Főoldal</a></div>';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Használtautó</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes" />
    
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />
    
    <script src="js/jquery.min.js"></script>
    <script src="js/jwerty.min.js"></script>
    <script src="js/script.js"></script>
    
</head>
<body>
    <div class="loading-overlay"></div>
    <div class="loading">
        <div>Töltés... Kérlek várj!</div>
        <img src="img/loader.gif" alt="Töltés..." />
    </div>
    <script>loading()</script>
    <div id="wrapper">
        <?php echo $eredmeny; ?>
    </div>
</body>
<script>loading(0)</script>
</html>