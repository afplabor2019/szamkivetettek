var muveletek = 'ajax.php';

function loading(type){
    if(type != 0) {
        $('.loading-overlay').fadeIn();
        $('.loading').fadeIn();
    } else {
        $('.loading-overlay').fadeOut();
        $('.loading').fadeOut();
    }
}

function login() {
    user = $('#user').val();
    pw = $('#pw').val();
    $.post(muveletek,{'muvelet':'login','user':user,'pw':pw}, function(data_returned){
        $('.login_err').html(data_returned);
    });
}
function lostpw() {
    email = $('#lostemail').val();
    u = $('#lostu').val();
    $.post(muveletek,{'muvelet':'lostpw','email':email,'u':u}, function(data_returned){
        $('.login_err').html(data_returned);
    });
}
function save_settings(){
    email = $('#email').val();
    megerosites = $('#megerosites').val();
    url = $('#url').val();
    oldal_nev = $('#oldal_nev').val();
    nyitott = $('#nyitott').val();
    max_users = $('#max_users').val();
    $.post(muveletek,{'muvelet':'save_settings','email':email,'url':url, 'megerosites':megerosites, 'oldal_nev':oldal_nev, 'nyitott':nyitott, 'max_users':max_users}, function(data_returned){
        $('.save_err').html(data_returned);
    });
}
function reg() {
    user = $('#wantuser').val();
    pw = $('#wantpw').val();
    rpw = $('#wantrpw').val();
    email = $('#wantemail').val();
    $.post(muveletek,{'muvelet':'reg','user':user,'pw':pw,'rpw':rpw,'email':email}, function(data_returned){
        $('.login_err').html(data_returned);
    });
}
function reg_form(){
    $('form.login').slideUp();
    $('form.reg').slideDown();
    $('h1.login').html('Regisztráció');
}
function login_form(){
    $('form.reg').slideUp();
    $('form.login').slideDown();
    $('h1.login').html('Bejelentkezés');
}
function login_form2(){
    $('form.reg, form.lostpw').slideUp();
    $('form.login').slideDown();
    $('h1.login').html('Bejelentkezés');
}
function lostpw_form(){
    $('form.login, form.reg').slideUp();
    $('form.lostpw').slideDown();
    $('h1.login').html('Jelszóújítás');
}
function check_pw(){
    wpw = $('#wantpw').val();
    wuser = $('#wantuser').val();
    if(wpw == wuser && wpw != '' && wuser != '') {
        $('.login_err').html('<div class="csik csik-info">Vigyázz! Ha a jelszavad és a felhasználóneved megegyezik, akkor nagyon könnyen fel lehet törni a fiókodat!</div>');
    } else {
        $('.login_err').html('');
    }
}