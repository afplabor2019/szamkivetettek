<?php
/*
    Ez a fájl az oldal fő beállításait tartalmazza
*/

//Fő beállítások
define('DEBUG_MODE', true); //Kiírja a hibákat vagy ne
define('SHA_ELO', 'gz8TDut67-');
define('SHA_UTO', 'a-t6HU76');
define('OLDAL_SESS', 'ag0wfh7A_V34EAFR67jsah'); //Kiírja a hibákat vagy ne

// MySQL adatok
define('SQLHOST', 'localhost'); //A MySQL host
define('SQLUSER', 'projekt');//A MySQL felhasználó
define('SQLPASS', '123456'); //A MySQL jelszó
define('SQLDB', 'loginrendszer'); //A MySQL adatbázis
define('SQLPORT',3306);
?>
