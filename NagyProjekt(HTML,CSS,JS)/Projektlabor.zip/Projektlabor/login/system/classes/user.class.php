<?php
/*
    A regisztráció osztály.
*/

class FELHASZNALO {    
    public $oldalSession = OLDAL_SESS;
    public $belepve = false;
    
    public function __construct(){
        if (isset($_SESSION[OLDAL_SESS])) $this->belepve = true;
    }
        
    /* Szabad felhasználó vizsgálat */
    public function szabad_user($u = ''){
        global $db;
        $db->query('SELECT id FROM users WHERE username="'. $u .'"');
        if($db->last_query_num()==0) return true;
        else return false;
    }
    public function all_users(){
        global $db;
        $db->query('SELECT id FROM users');
        return $db->last_query_num();
    }
    public function lostpw($u = '',$email = '') {
        global $db;
        /* Ellenőrizzük, hogy regelve van-e az e-mail */
        $c = $db->num_rows('SELECT id FROM users WHERE username="'. $u .'" AND email="'. $email .'"');
        
        if($c != 0){
            $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 10; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            $newpw = implode($pass); //turn the array into a string
            $db->query('UPDATE users SET pw="'. titkositas($newpw) .'" WHERE username="'. $u .'" AND email="'. $email .'"');
            sendLostMail($email,$u,$newpw);
            echo '<div class="csik csik-jo">Az új jelszót elküldtük az e-mail címedre (<b>'. $email .'</b>).</div>';
        } else die('<div class="csik csik-veszely">Rossz felhasználónév vagy e-mail cím.</div>');
        

    }
    public function user_adatai(){
        global $db;
        $db->query('SELECT * FROM users WHERE id='.$_SESSION[OLDAL_SESS]);
        return $db->fetch_arr();
    }
    /* REGISZTRÁCIÓ */
    public function reg($u = '', $pw = '', $rpw = '', $email = ''){
        global $db,$settings;
        
        
        /* REG ELLENŐRZÉSEK */
        if (strlen($u)<5) die('<div class="csik csik-veszely">A felhasználónév min. 5 karakter kell hogy legyen!</div>');
        if (strlen($pw)<5) die('<div class="csik csik-veszely">A jelszó legalább 5 karakter kell hogy legyen!</div>');
        if(!joemail($email)) die('<div class="csik csik-veszely">Valódi e-mail címet adj meg!</div>');
        if($pw != $rpw) die('<div class="csik csik-veszely">A jelszavak nem egyeznek!</div>');
        // Szabad felhasználónév
        if(!$this->szabad_user($u)) die('<div class="csik csik-veszely">Ez a felhasználónév már foglalt!</div>');
        /* Szabad-e a regisztrálás egyáltalán? */
        if(!$settings['nyilt_reg'] || $this->all_users() > $settings['max_users']) die('<div class="csik csik-veszely">A regisztráció ki van kapcsolva</div>');
        
        /* REG ELLENŐRZÉSEK VÉGE */
        
        $db->query('INSERT INTO users (username,pw,email,regido,ip) VALUES ("'. $u .'","'. titkositas($pw) .'","'. $email .'",NOW(),"'. getip() .'")');
        if ($db->lastQuery) return true;
        else return false;
        
        sendRegMail($email,$u,titkositas($pw));
    }
    
    /* Bejelentkezés */
    public function login($u = '', $pw = ''){
        global $db,$settings;
        $db->query('SELECT status FROM users WHERE username="'. $u .'"');
        $status = $db->fetch_arr();
        #Meg van erősítve?
        if($settings['kell_email'] == 'igen' && $status['status'] == 'progress') die('<div class="csik csik-veszely">Kérlek bejelentkezés előtt erősítsd meg az e-mail címedet!</div>'); 
        
        if($db->num_rows('SELECT id FROM users WHERE username="'. $u .'" AND pw="'. titkositas($pw) .'"') == 1){
            $res = $db->fetch_arr();
            
            $_SESSION[$this->oldalSession] = $res['id'];
            $db->query('UPDATE users SET ip="'. getip() .'", last_login=NOW() WHERE id='.$res['id']); // Megváltoztatjuk a az ip címet és az uccsó bejelentkezési időt
            $this->belepve = true;

            atiranyit('belepve','html');
        }
        else echo '<div class="csik csik-veszely">Rossz felhasználónév vagy jelszó! <a href="#" onclick="lostpw_form()">Elfelejtetted a jelszavad?</a></div>';
    }
    
    /* Védett oldalak */
    public function vedelem($tipus = 'vedett'){
        if($tipus == 'vedett'){
            if(!$this->belepve) atiranyit('fooldal');
        } else if($this->belepve) atiranyit('belepve');
    }
    
    
    /* Kijelentkezés */
    public function logout(){
        session_destroy();
        session_unset();
        
        atiranyit('fooldal');
    }
}

?>