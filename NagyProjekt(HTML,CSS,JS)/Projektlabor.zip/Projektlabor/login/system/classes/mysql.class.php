<?php
if (!extension_loaded('mysqli')) {
	die('Mysqli Extension not loaded.');
}
class DB_MYSQL { 
    public $debugMode = DEBUG_MODE;
    
    public $kapcs = '';
    public $lastError = '';
    public $lastQuery = '';
    public $result = '';
    public $arrayResult = '';
    public $link = '';
    public $rowNum = 0;
    
    
    public $sqldb = '';
    public $sqlhost = '';
    public $sqluser = '';
    public $sqlpass = '';
    public $sqlport = 0;
    
    public function __construct($sqldb = SQLDB, $sqlhost = SQLHOST, $sqluser = SQLUSER, $sqlpass = SQLPASS, $sqlport = SQLPORT) {
        $this->sqldb = SQLDB;
        $this->sqlhost = SQLHOST;
        $this->sqluser = SQLUSER;
        $this->sqlpass = SQLPASS;
        $this->sqlport = SQLPORT;
        
        $this->connect();
    }

    /* Connect fgv */
    public function connect(){
        // Kapcsolódunk az adatbázishoz
        $this->kapcs = mysqli_connect($this->sqlhost,$this->sqluser,$this->sqlpass,$this->sqldb,$this->sqlport);
        if(!$this->kapcs){
            $this->lastError = 'Nem sikerült kapcsolódni az adatbázishoz: '.mysqli_connect_error();
            if($this->debugMode) echo $this->lastError;
        }
    }
    
    /* Query fgv */
    public function query($sql = ''){
        $this->lastQuery = mysqli_query($this->kapcs,$sql);
    }
    
    public function fetch_arr() {
        return mysqli_fetch_array($this->lastQuery, MYSQLI_BOTH);
    }
    
    /* Sorok száma */
    public function last_query_num(){
		if ($this->lastQuery) {
			return mysqli_num_rows($this->lastQuery);
		}
    }
    public function num_rows($sql = ''){
        $this->query($sql);
        return mysqli_num_rows($this->lastQuery);
    }
  }

$db = new DB_MYSQL;

/* Fő beállítások lekérése */
$db->query('SELECT * FROM settings');
$settings = $db->fetch_arr();
?>