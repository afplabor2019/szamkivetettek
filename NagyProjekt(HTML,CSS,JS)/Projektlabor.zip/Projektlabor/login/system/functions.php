<?php
/* Funkci�k */
/* Titkos�t�s (sha1) */
function titkositas($titkositando = '', $sha1 = ''){
    $sha1 = sha1($titkositando);
    return sha1(SHA_ELO.$sha1.SHA_UTO);
}

/* IP c�m lek�r�se */
function getip(){
    $ip = '';
    if (getenv("HTTP_CLIENT_IP"))
        $ip = getenv("HTTP_CLIENT_IP");
    elseif(getenv("HTTP_X_FORWARDED_FOR"))
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    elseif(getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR");
    else
        $ip = "ismeretlen";
    return $ip;
}

/* �tir�ny�t�s */
function atiranyit($hova = '',$tipus = 'php'){
    switch ($tipus){
        case 'php':
            header('Location: '.$hova);
        break;
        case 'html':
            echo '<script>window.location="'. $hova .'"</script>';
        break;
        case 'js':
            echo 'window.location="'. $hova .'"';
        break;
    }
}

/* E-mail ellen�rz�s */
function joemail($email) {
    return preg_match('/^[\w.-]+@([\w.-]+\.)+[a-z]{2,6}$/is', $email);
}

?>