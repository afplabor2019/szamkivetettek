<?php
/*
    Minden oldal elején be kell hívni, mert ez tartalmazza a behívásokat, meg mindent ami
    az oldal indulásához és működéséhez kell!
*/

// Karakterkódolás
header ('Content-Type: text/html; charset=utf-8');

require 'system/config.php'; // Az oldal főbeállításait tartalmazó php fájl

session_start();

require('system/functions.php');

/* Classok */
require 'classes/mysql.class.php';
require 'classes/user.class.php';

function sendRegMail($email = '',$user = '',$pw = ''){
    global $settings;
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: '. $settings['oldal_nev'] .' <'. $settings['email'] .'>' . "\r\n";

    mail($email,'Sikeresen regisztráció!',
'<table style="color: #333; border: none; font-family: \'segoe ui\',verdana,arial; font-size: 17px; width: 800px;">
    <tr style="height: 60px;">
        <td style="font-size: 24px; color: #444;font-weight: bold;">Sikeres regisztráció!</td>
    </tr>
    <tr>
        <td>Köszönjük a regisztrációdat '. $user .'!<hr style="border: none;border-top: 1px solid rgb(219, 218, 218);" /></td>
    </tr>
    <tr>
        <td>Ha valóban te regisztráltál, akkor az alábbi linken visszaigazolhatod ezt az e-mail címet, és már használhatod is az oldalt.</td>
    </tr>
    <tr style="height: 70px;background: #E3E8EE;text-align:center">
        <td><a style="color: #fff;text-decoration: none;background: #1F63F3;padding: 5px 10px;font-size: 14px;cursor: pointer;border: 1px solid #3B69C7;" href="'. $settings['url'] .'/megerosites.php?u='. $user .'&pw='. $pw .'">E-mail cím visszaigazolása</a></td>
    </tr>
    <tr>
        <td>Üdvözöl téged a <b>PHPműhely</b></td>
    </tr>
</table>',$headers);
}
function sendLostMail($email = '',$user = '', $pw = ''){
    global $settings;
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From: '. $settings['oldal_nev'] .' <'. $settings['email'] .'>' . "\r\n";

    mail($email,'Elfelejtett jelszó',
'<table style="color: #333; border: none; font-family: \'segoe ui\',verdana,arial; font-size: 17px; width: 800px;">
    <tr style="height: 60px;">
        <td style="font-size: 24px; color: #444;font-weight: bold;">Új jelszót igényeltél</td>
    </tr>
    <tr>
        <td>Kedves '. $user .'!<hr style="border: none;border-top: 1px solid rgb(219, 218, 218);" /></td>
    </tr>
    <tr>
        <td>Elfelejtetted a jelszavad, és újat igényeltél. Kérjük, jelentkezz be az új jelszóval és változtasd is meg.</td>
    </tr>
    <tr style="height: 70px;background: #E3E8EE;text-align:center">
        <td>Az új jelszavad: <b>'. $pw .'</b></td>
    </tr>
    <tr>
        <td>Üdvözöl téged a <b>'. $settings['oldal_nev'] .'</b></td>
    </tr>
</table>',$headers);
}
?>